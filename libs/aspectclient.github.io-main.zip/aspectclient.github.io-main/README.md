# Aspect Client - Website
## Steps to Commit
- Create a new branch, with the format `username_client-build-version`
- Go to the [Gitmoji Website](https://gitmoji.dev/) and look for the appropriate emoji.
Then type a summary of the commit as the commit header, with the emoji from before first. (example: `:bug: Fixed Microsoft Auth Bug`)
- Once ready, open a pull request.
- **DO NOT ACCEPT YOUR OWN PULL REQUEST!!!**
